var express = require('express');
var _ = require('lodash');
var cors = require('cors');
var app = express();
app.use(cors())

var users = [
  { username: "jessi", email: "jessi@gmail.com", age: 18 },
  { username: "vane", email: "vane@gmail.com", age: 19 },
  { username: "samantha", email: "samantha@gmail.com", age: 22 },
  { username: "jenni", email: "jenni@gmail.com", age: 25 },
  { username: "sheila", email: "sheila@gmail.com", age: 27 },
  { username: "barbara", email: "barbara@gmail.com", age: 20 },
  { username: "saray", email: "saray@gmail.com", age: 20 },
  { username: "amanda", email: "amanda@gmail.com", age: 30 },
  { username: "deborah", email: "deborah@gmail.com", age: 29 },
  { username: "juani", email: "juani@gmail.com", age: 31 },
  { username: "sarah", email: "sarah@gmail.com", age: 26 },
  { username: "tamara", email: "tamara@gmail.com", age: 22 },
  { username: "natasha", email: "natasha@gmail.com", age: 31 },
  { username: "alexandra", email: "alexandra@gmail.com", age: 32 },
  { username: "anastasia", email: "anastasia@gmail.com", age: 40 },
  { username: "annushka", email: "annushka@gmail.com", age: 35 },
  { username: "tanya", email: "tanya@gmail.com", age: 29 }
]

app.get('/users', function (req, res) {
  if (req.query.query) {
    users = _.filter(users, function(user) { return user.username.indexOf(req.query.query) > -1; });
  }
  if(req.query.order_by) {
    users = _.sortBy(users, function(user) { return user[req.query.order_by]; });
  }
  if(req.query.sort && req.query.sort.toLowerCase()=='desc') {
    users = _(users).reverse().value();
  }
  if(req.query.skip && req.query.limit) {
    users = users.slice(Number(req.query.skip), (Number(req.query.skip)+Number(req.query.limit)))
  }

  return res.json(users);
});

app.listen(3000, function () {
  console.log('Users fake app listening on port 3000!');
});