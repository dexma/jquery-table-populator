# Fake users APP in nodejs #


## Installation ##

Install node js :

https://nodejs.org/en/download/

Install npm (javascript dependencies manager):

https://docs.npmjs.com/getting-started/installing-node

If you use ubuntu:
```shell
sudo apt-get install nodejs
sudo apt-get install npm
```

Go to source folder and install dependencies :

```shell
npm i --save express 
npm i --save lodash
npm i --save cors 
```

 -  Express : http://expressjs.com/
 -  Lodash : https://lodash.com/ 
 -  Cors : https://github.com/expressjs/cors

## Run app ##

Run node :

```
node app.js
```

In your browser :

http:localhost:3000/users

http:localhost:3000/users?order_by=email

http:localhost:3000/users?query=an

http:localhost:3000/users?query=a&skip=2&limit=3
